import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_task_app/models/task.dart';

class StorageService {
  static const String _tasksKey = 'tasks';

  // Salvar a lista de tarefas
  Future<void> saveTasks(List<Task> tasks) async {
    final prefs = await SharedPreferences.getInstance();
    final tasksJson = tasks.map((task) => jsonEncode({
          'id': task.id,
          'title': task.title,
          'description': task.description,
          'priority': task.priority,
          'isCompleted': task.isCompleted,
        })).toList();
    
    await prefs.setStringList(_tasksKey, tasksJson);
  }

  // Carregar a lista de tarefas
  Future<List<Task>> loadTasks() async {
    final prefs = await SharedPreferences.getInstance();
    final tasksJson = prefs.getStringList(_tasksKey) ?? [];
    
    return tasksJson.map((taskJson) {
      final taskMap = jsonDecode(taskJson);
      return Task(
        id: taskMap['id'],
        title: taskMap['title'],
        description: taskMap['description'],
        priority: taskMap['priority'],
        isCompleted: taskMap['isCompleted'],
      );
    }).toList();
  }
}
