import 'package:flutter/material.dart';
import 'package:flutter_task_app/models/task.dart';
import 'package:flutter_task_app/pages/about_page.dart';
import 'package:flutter_task_app/pages/task_form_page.dart';
import 'package:flutter_task_app/services/storage_service.dart';

class TaskListPage extends StatefulWidget {
  const TaskListPage({super.key});

  @override
  State<TaskListPage> createState() => _TaskListPageState();
}

class _TaskListPageState extends State<TaskListPage> {
  final StorageService _storageService = StorageService();
  List<Task> tasks = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadTasks();
  }

  Future<void> _loadTasks() async {
    try {
      final loadedTasks = await _storageService.loadTasks();
      setState(() {
        tasks = loadedTasks;
        if (tasks.isEmpty) {
          // Adicionar tarefas de exemplo apenas se não houver tarefas salvas
          tasks = [
            Task(
              id: '1',
              title: 'Comprar mantimentos',
              description: 'Leite, pão, ovos e frutas',
              priority: 'Alta',
            ),
            Task(
              id: '2',
              title: 'Estudar Flutter',
              description: 'Revisar widgets e gerenciamento de estado',
              priority: 'Média',
            ),
            Task(
              id: '3',
              title: 'Fazer exercícios',
              description: '30 minutos de caminhada',
              priority: 'Baixa',
            ),
          ];
          _saveTasks(); // Salvar as tarefas de exemplo
        }
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      _showErrorSnackBar('Erro ao carregar tarefas: $e');
    }
  }

  Future<void> _saveTasks() async {
    try {
      await _storageService.saveTasks(tasks);
    } catch (e) {
      _showErrorSnackBar('Erro ao salvar tarefas: $e');
    }
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // Cores para as prioridades
  Color _getPriorityColor(String priority) {
    switch (priority) {
      case 'Alta':
        return Colors.red.shade100;
      case 'Média':
        return Colors.orange.shade100;
      case 'Baixa':
        return Colors.green.shade100;
      default:
        return Colors.grey.shade100;
    }
  }

  void _deleteTask(int index, Task task) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirmar exclusão'),
        content: Text('Deseja realmente excluir a tarefa "${task.title}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                tasks.removeAt(index);
              });
              _saveTasks(); // Salvar após excluir
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Tarefa "${task.title}" removida'),
                  duration: const Duration(seconds: 2),
                ),
              );
            },
            child: const Text('Excluir', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Minhas Tarefas'),
        backgroundColor: Theme.of(context).colorScheme.primaryContainer,
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const AboutPage()),
              );
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : tasks.isEmpty
              ? const Center(
                  child: Text(
                    'Nenhuma tarefa encontrada.\nAdicione uma nova tarefa!',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16),
                  ),
                )
              : ListView.builder(
                  itemCount: tasks.length,
                  itemBuilder: (context, index) {
                    final task = tasks[index];
                    return Dismissible(
                      key: Key(task.id),
                      background: Container(
                        color: Colors.red,
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 20),
                        child: const Icon(
                          Icons.delete,
                          color: Colors.white,
                        ),
                      ),
                      direction: DismissDirection.endToStart,
                      onDismissed: (direction) {
                        setState(() {
                          tasks.removeAt(index);
                        });
                        _saveTasks(); // Salvar após excluir
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Tarefa "${task.title}" removida'),
                            duration: const Duration(seconds: 2),
                          ),
                        );
                      },
                      child: Card(
                        margin: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        color: _getPriorityColor(task.priority),
                        child: ListTile(
                          title: Text(
                            task.title,
                            style: TextStyle(
                              decoration: task.isCompleted
                                  ? TextDecoration.lineThrough
                                  : null,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          subtitle: Text(task.description),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Checkbox(
                                value: task.isCompleted,
                                onChanged: (value) {
                                  setState(() {
                                    tasks[index] = task.copyWith(
                                      isCompleted: value,
                                    );
                                  });
                                  _saveTasks(); // Salvar após atualizar
                                },
                              ),
                              IconButton(
                                icon: const Icon(Icons.edit),
                                onPressed: () async {
                                  final result = await Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => TaskFormPage(
                                        task: task,
                                        isEditing: true,
                                      ),
                                    ),
                                  );
                                  if (result != null && result is Task) {
                                    setState(() {
                                      tasks[index] = result;
                                    });
                                    _saveTasks(); // Salvar após editar
                                  }
                                },
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete, color: Colors.red),
                                onPressed: () {
                                  _deleteTask(index, task);
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const TaskFormPage(),
            ),
          );
          if (result != null && result is Task) {
            setState(() {
              tasks.add(result);
            });
            _saveTasks(); // Salvar após adicionar
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
